package a.a2;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Simple tests for the B class.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2004/04/20 23:40:21 $
 * @since     December 2, 2003
 */
public class BUTest extends TestCase
{
    private static final Class THIS_CLASS = BUTest.class;
    
    public BUTest( String name )
    {
        super( name );
    }


    //-------------------------------------------------------------------------
    // Tests
    
    public void testGetNext()
    {
        B b = new B();
        assertEquals( -1, b.getNext() );
        assertEquals( -2, b.getNext() );
        assertEquals( -3, b.getNext() );
    }
    
    
    //-------------------------------------------------------------------------
    // Standard JUnit declarations
    
    
    public static Test suite()
    {
        TestSuite suite = new TestSuite( THIS_CLASS );
        
        return suite;
    }
}

