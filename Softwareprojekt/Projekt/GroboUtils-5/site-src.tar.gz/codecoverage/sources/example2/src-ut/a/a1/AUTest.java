package a.a1;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Simple tests for the A class.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2004/04/20 23:40:18 $
 * @since     December 2, 2003
 */
public class AUTest extends TestCase
{
    private static final Class THIS_CLASS = AUTest.class;
    
    public AUTest( String name )
    {
        super( name );
    }


    //-------------------------------------------------------------------------
    // Tests
    
    public void testGetNext()
    {
        A a = new A();
        assertEquals( 1, a.getNext() );
        assertEquals( 2, a.getNext() );
        assertEquals( 3, a.getNext() );
    }
    
    
    //-------------------------------------------------------------------------
    // Standard JUnit declarations
    
    
    public static Test suite()
    {
        TestSuite suite = new TestSuite( THIS_CLASS );
        
        return suite;
    }
}

