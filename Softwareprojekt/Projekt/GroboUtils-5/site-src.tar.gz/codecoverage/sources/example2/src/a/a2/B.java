package a.a2;

import a.a1.IA;

/**
 * Example class file.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2003/12/03 22:25:43 $
 * @since     December 2, 2003
 */
public class B implements IA
{
    int value = 0;
    
    private class MyInner
    {
        public int next()
        {
            if (value == -100)
            {
                // should never be exercised in tests.
                value = -10000;
            }
            else
            {
                --value;
            }
            return value;
        }
    }
    
    MyInner inner = new MyInner();
    
    public int getNext()
    {
        return inner.next();
    }
    
    
    protected int peek()
    {
        // never called in tests.
        return value;
    }
}
