package a.a2;

/**
 * Example class file.  Not to be tested (for 0 coverage report test)
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2004/02/25 22:29:48 $
 * @since     February 25, 2004
 */
public class D
{
    public void doSomething()
    {
        int i = 0;
        ++i;
        System.out.println("on "+i);
        try
        {
            new Exception();
        }
        catch (Exception e)
        {
            ++i;
        }
        finally
        {
            ++i;
        }
    }
}
