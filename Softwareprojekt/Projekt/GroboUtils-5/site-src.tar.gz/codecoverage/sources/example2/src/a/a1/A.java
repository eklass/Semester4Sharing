package a.a1;

/**
 * Example class file.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2003/12/02 23:26:44 $
 * @since     December 2, 2003
 */
public class A implements IA
{
    int value = 0;
    public int getNext()
    {
        return ++value;
    }
}
