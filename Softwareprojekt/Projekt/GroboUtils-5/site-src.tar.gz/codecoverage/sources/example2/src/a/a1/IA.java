package a.a1;

/**
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2003/12/02 23:26:44 $
 * @since     December 2, 2003
 */
public interface IA
{
    public int getNext();
}
