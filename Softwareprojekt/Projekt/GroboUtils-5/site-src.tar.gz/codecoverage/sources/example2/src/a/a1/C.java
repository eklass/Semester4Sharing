package a.a1;

/**
 * Example class file.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2003/12/17 21:52:48 $
 * @since     December 2, 2003
 */
public class C
{
    public boolean returnTrue()
    {
        int i = 0;
        if (i != 0)
        {
            return false;
        }
        return true;
    }
}
