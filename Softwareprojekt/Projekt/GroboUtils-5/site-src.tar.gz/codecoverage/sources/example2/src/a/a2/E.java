package a.a2;

/**
 * Example class file.  Covers bug 902884.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2004/04/20 23:37:26 $
 * @since     April 20, 2004
 */
public class E
{
    public E() {}
}
