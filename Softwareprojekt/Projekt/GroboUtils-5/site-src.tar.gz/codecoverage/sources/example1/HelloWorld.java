
/**
 * Example class file.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2003/11/22 07:13:15 $
 * @since     November 15, 2003
 */
public class HelloWorld
{
    public void execute()
    {
        System.out.println( getText() );
    }
    
    
    String getText()
    {
        return "Hello, world!";
    }
}
