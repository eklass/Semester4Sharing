
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * Simple tests for the HelloWorld class.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2003/11/22 07:13:15 $
 * @since     November 15, 2003
 */
public class HelloWorldUTest extends TestCase
{
    private static final Class THIS_CLASS = HelloWorldUTest.class;
    
    public HelloWorldUTest( String name )
    {
        super( name );
    }


    //-------------------------------------------------------------------------
    // Tests
    
    public void testGetText()
    {
        HelloWorld hw = new HelloWorld();
        String t = hw.getText();
        assertEquals( "did not return correct text.",
            "Hello, world!",
            t );
    }
    
    
    public void testExecute()
    {
        HelloWorld hw = new HelloWorld();
        hw.execute();
    }
    
    
    //-------------------------------------------------------------------------
    // Standard JUnit declarations
    
    
    public static Test suite()
    {
        TestSuite suite = new TestSuite( THIS_CLASS );
        
        return suite;
    }
}

