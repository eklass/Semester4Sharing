/*
 * @(#)ILogFilter.java
 *
 * Copyright (C) 2004 Matt Albrecht
 * groboclown@users.sourceforge.net
 * http://groboutils.sourceforge.net
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a
 *  copy of this software and associated documentation files (the "Software"),
 *  to deal in the Software without restriction, including without limitation
 *  the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *  and/or sell copies of the Software, and to permit persons to whom the
 *  Software is furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 *  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *  DEALINGS IN THE SOFTWARE.
 */

package net.sourceforge.groboutils.codecoverage.v2.util;

import java.io.File;
import java.io.IOException;


/**
 * Describes a method to transform a specialized log format into the
 * standard format.  Implementations must have a no-arg constructor.
 *
 * @author    Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version   $Date: 2004/04/17 08:25:53 $
 * @since     April 16, 2004
 */
public interface ILogFilter
{
    /**
     * Loads all data from the given log directory, and outputs the
     * standard format in the same place.  This should only fail on
     * I/O errors, not on format errors.
     *
     * @param channelCount the number of channels that the output logging
     *      should use.
     * @param dir the directory where all the logs should live.
     * @exception IOException if there is an I/O error reading from <tt>r</tt>.
     * @exception IllegalArgumentException if the reader is <tt>null</tt>.
     */
    public void process( int channelCount, File dir )
            throws IOException;
}

