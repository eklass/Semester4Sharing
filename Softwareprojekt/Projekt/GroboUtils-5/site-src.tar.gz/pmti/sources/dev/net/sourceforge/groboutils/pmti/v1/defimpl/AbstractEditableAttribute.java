/*
 *  @(#)AbstractEditableAttribute.java
 *
 * Copyright (C) 2002-2003 Matt Albrecht
 * groboclown@users.sourceforge.net
 * http://groboutils.sourceforge.net
 *
 *  Part of the GroboUtils package at:
 *  http://groboutils.sourceforge.net
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a
 *  copy of this software and associated documentation files (the "Software"),
 *  to deal in the Software without restriction, including without limitation
 *  the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *  and/or sell copies of the Software, and to permit persons to whom the 
 *  Software is furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in 
 *  all copies or substantial portions of the Software. 
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL 
 *  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
 *  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 *  DEALINGS IN THE SOFTWARE.
 */
package net.sourceforge.groboutils.pmti.v1.defimpl;

import net.sourceforge.groboutils.pmti.v1.IEditableAttribute;
import net.sourceforge.groboutils.pmti.v1.IAttributeInfo;
import net.sourceforge.groboutils.pmti.v1.IAttribute;
 

/**
 * This uses delegation to allow for maximum flexibility in creating new
 * editable attributes based on this class through subclassing.
 *
 * @author     Matt Albrecht <a href="mailto:groboclown@users.sourceforge.net">groboclown@users.sourceforge.net</a>
 * @version    $Date: 2003/02/10 22:51:57 $
 * @since      July 12, 2002
 */
public abstract class AbstractEditableAttribute implements IEditableAttribute
{
    private Object newvalue;
    private boolean valueChanged = false;
    private IAttribute baseAttrib;
    
    
    public AbstractEditableAttribute( IAttribute base )
    {
        if (base == null)
        {
            throw new IllegalArgumentException("no null arguments");
        }
        this.baseAttrib = base;
    }
    
    
    
    /**
     * Returns the current (possibly modified) value for this attribute.
     */
    public Object getValue()
    {
        Object ret;
        if (this.valueChanged)
        {
            ret = this.newvalue;
        }
        else
        {
            ret = this.baseAttrib.getValue();
        }
        return ret;
    }
    
    
    /**
     * Returns the meta-information for this attribute.
     */
    public IAttributeInfo getInfo()
    {
        return this.baseAttrib.getInfo();
    }
    
    
    /**
     * @exception IllegalArgumentException thrown if the value argument is
     *      invalid.
     */
    public void setValue( Object value )
    {
        if (!isValidValue( value ))
        {
            throw new IllegalArgumentException( "invalid value "+value );
        }
        Object orig = this.baseAttrib.getValue();
        if ( value == orig || ( value != null && value.equals( orig ) ) )
        {
            // no change from the original
            this.valueChanged = false;
        }
        else
        {
            this.valueChanged = true;
            this.newvalue = value;
        }
    }
    
    
    /**
     * @return <tt>true</tt> if the <tt>setValue( Object )</tt> method has
     *      been called on this instance and the actual value has changed
     *      (via inspection with <tt>==</tt> and <tt>equals()</tt>),
     *      otherwise <tt>false</tt>.
     */
    public boolean hasValueChanged()
    {
        return this.valueChanged;
    }
    
    
    /**
     * 
     */
    public abstract boolean isValidValue( Object value );
}

